--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acronimo; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE acronimo (
    id integer NOT NULL,
    name character varying(10)
);


ALTER TABLE public.acronimo OWNER TO gpidote;

--
-- Name: acronimo_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE acronimo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acronimo_id_seq OWNER TO gpidote;

--
-- Name: acronimo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE acronimo_id_seq OWNED BY acronimo.id;


--
-- Name: asociado; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE asociado (
    id integer NOT NULL,
    name character varying(50)
);


ALTER TABLE public.asociado OWNER TO gpidote;

--
-- Name: asociado_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE asociado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asociado_id_seq OWNER TO gpidote;

--
-- Name: asociado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE asociado_id_seq OWNED BY asociado.id;


--
-- Name: conservacion; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE conservacion (
    id integer NOT NULL,
    name character varying(50)
);


ALTER TABLE public.conservacion OWNER TO gpidote;

--
-- Name: conservacion_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE conservacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conservacion_id_seq OWNER TO gpidote;

--
-- Name: conservacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE conservacion_id_seq OWNED BY conservacion.id;


--
-- Name: datacion; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE datacion (
    id integer NOT NULL,
    name character varying(5)
);


ALTER TABLE public.datacion OWNER TO gpidote;

--
-- Name: datacion_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE datacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.datacion_id_seq OWNER TO gpidote;

--
-- Name: datacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE datacion_id_seq OWNED BY datacion.id;


--
-- Name: edad; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE edad (
    id integer NOT NULL,
    name character varying(20)
);


ALTER TABLE public.edad OWNER TO gpidote;

--
-- Name: edad_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE edad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.edad_id_seq OWNER TO gpidote;

--
-- Name: edad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE edad_id_seq OWNED BY edad.id;


--
-- Name: ingreso; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE ingreso (
    id integer NOT NULL,
    name character varying(15)
);


ALTER TABLE public.ingreso OWNER TO gpidote;

--
-- Name: ingreso_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE ingreso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingreso_id_seq OWNER TO gpidote;

--
-- Name: ingreso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE ingreso_id_seq OWNED BY ingreso.id;


--
-- Name: integridad; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE integridad (
    id integer NOT NULL,
    name character varying(10)
);


ALTER TABLE public.integridad OWNER TO gpidote;

--
-- Name: integridad_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE integridad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integridad_id_seq OWNER TO gpidote;

--
-- Name: integridad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE integridad_id_seq OWNED BY integridad.id;


--
-- Name: io; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE io (
    id integer NOT NULL,
    ficharesumen character varying(50),
    nroregistro character varying(50),
    sitio character varying(150),
    acronimo character varying(10),
    localidad character varying(150),
    provincia character varying(150),
    periodo character varying(50),
    coordsitio character varying(30),
    "precision" character varying(25),
    dataciones character varying(50),
    shueso character varying(4),
    materialasoc character varying(4),
    arqueologo character varying(150),
    fechainicio character varying(50),
    fechafin character varying(50),
    enterespon text,
    nroregistroarq character varying(50),
    sepultura character varying(50),
    sexo character varying(3),
    edad character varying(25),
    "años" character varying(50),
    integridad character varying(50),
    elementoseos character varying(10),
    preservacion character varying(50),
    conservacion character varying(25),
    patalogesquel character varying(4),
    patologdientes character varying(4),
    elemasoc character varying(50),
    otrosasoc character varying(50),
    vestimasoc character varying(50),
    inventario text,
    fotografias character varying(4),
    bibliograf text,
    fechaingreso timestamp without time zone,
    caja character varying(5),
    sala character varying(5),
    estanteria character varying(4),
    plano character varying(4),
    restoshumanos character varying(50),
    otrosrestos character varying(50),
    formaingreso character varying(50),
    fechasalida timestamp without time zone,
    regitroresponsable character varying(50),
    conservacrespons character varying(50),
    digitalizarespons character varying(50),
    bodegaje character varying(50),
    observaciones text
);


ALTER TABLE public.io OWNER TO gpidote;

--
-- Name: io_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE io_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.io_id_seq OWNER TO gpidote;

--
-- Name: io_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE io_id_seq OWNED BY io.id;


--
-- Name: localidad; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE localidad (
    id integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.localidad OWNER TO gpidote;

--
-- Name: localidad_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE localidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.localidad_id_seq OWNER TO gpidote;

--
-- Name: localidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE localidad_id_seq OWNED BY localidad.id;


--
-- Name: otroresto; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE otroresto (
    id integer NOT NULL,
    name character varying(10)
);


ALTER TABLE public.otroresto OWNER TO gpidote;

--
-- Name: TABLE otroresto; Type: COMMENT; Schema: public; Owner: gpidote
--

COMMENT ON TABLE otroresto IS '
';


--
-- Name: otroresto_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE otroresto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.otroresto_id_seq OWNER TO gpidote;

--
-- Name: otroresto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE otroresto_id_seq OWNED BY otroresto.id;


--
-- Name: precision; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE "precision" (
    id integer NOT NULL,
    name character varying(15)
);


ALTER TABLE public."precision" OWNER TO gpidote;

--
-- Name: preservacion; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE preservacion (
    id integer NOT NULL,
    name character varying(10)
);


ALTER TABLE public.preservacion OWNER TO gpidote;

--
-- Name: preservacion_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE preservacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preservacion_id_seq OWNER TO gpidote;

--
-- Name: preservacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE preservacion_id_seq OWNED BY preservacion.id;


--
-- Name: presicion_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE presicion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presicion_id_seq OWNER TO gpidote;

--
-- Name: presicion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE presicion_id_seq OWNED BY "precision".id;


--
-- Name: provincia; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE provincia (
    id integer NOT NULL,
    name character varying(30)
);


ALTER TABLE public.provincia OWNER TO gpidote;

--
-- Name: provincia_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE provincia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provincia_id_seq OWNER TO gpidote;

--
-- Name: provincia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE provincia_id_seq OWNED BY provincia.id;


--
-- Name: sepultura; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE sepultura (
    id integer NOT NULL,
    name character varying(25)
);


ALTER TABLE public.sepultura OWNER TO gpidote;

--
-- Name: sepultura_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE sepultura_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sepultura_id_seq OWNER TO gpidote;

--
-- Name: sepultura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE sepultura_id_seq OWNED BY sepultura.id;


--
-- Name: sexo; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE sexo (
    id integer NOT NULL,
    name character varying(1)
);


ALTER TABLE public.sexo OWNER TO gpidote;

--
-- Name: sexo_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE sexo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sexo_id_seq OWNER TO gpidote;

--
-- Name: sexo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE sexo_id_seq OWNED BY sexo.id;


--
-- Name: sitio; Type: TABLE; Schema: public; Owner: gpidote; Tablespace: 
--

CREATE TABLE sitio (
    id integer NOT NULL,
    name character varying(50)
);


ALTER TABLE public.sitio OWNER TO gpidote;

--
-- Name: sitio_id_seq; Type: SEQUENCE; Schema: public; Owner: gpidote
--

CREATE SEQUENCE sitio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sitio_id_seq OWNER TO gpidote;

--
-- Name: sitio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gpidote
--

ALTER SEQUENCE sitio_id_seq OWNED BY sitio.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY acronimo ALTER COLUMN id SET DEFAULT nextval('acronimo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY asociado ALTER COLUMN id SET DEFAULT nextval('asociado_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY conservacion ALTER COLUMN id SET DEFAULT nextval('conservacion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY datacion ALTER COLUMN id SET DEFAULT nextval('datacion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY edad ALTER COLUMN id SET DEFAULT nextval('edad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY ingreso ALTER COLUMN id SET DEFAULT nextval('ingreso_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY integridad ALTER COLUMN id SET DEFAULT nextval('integridad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY io ALTER COLUMN id SET DEFAULT nextval('io_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY localidad ALTER COLUMN id SET DEFAULT nextval('localidad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY otroresto ALTER COLUMN id SET DEFAULT nextval('otroresto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY "precision" ALTER COLUMN id SET DEFAULT nextval('presicion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY preservacion ALTER COLUMN id SET DEFAULT nextval('preservacion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY provincia ALTER COLUMN id SET DEFAULT nextval('provincia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY sepultura ALTER COLUMN id SET DEFAULT nextval('sepultura_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY sexo ALTER COLUMN id SET DEFAULT nextval('sexo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gpidote
--

ALTER TABLE ONLY sitio ALTER COLUMN id SET DEFAULT nextval('sitio_id_seq'::regclass);


--
-- Data for Name: acronimo; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY acronimo (id, name) FROM stdin;
1	LEEH
2	CV
3	NJ
4	CMS
5	LM
6	SnG
7	PaK
8	LHs
9	CVs
10	LPü
11	LVA
12	ESC
13	NdJ
14	RdB
15	MnE
16	PE
17	Cob
\.


--
-- Name: acronimo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('acronimo_id_seq', 17, true);


--
-- Data for Name: asociado; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY asociado (id, name) FROM stdin;
1	Cajón
2	Vestimenta asociada
3	Otros restos
4	Ninguno
5	Sin condiciones de análisis
\.


--
-- Name: asociado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('asociado_id_seq', 5, true);


--
-- Data for Name: conservacion; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY conservacion (id, name) FROM stdin;
1	Presente
2	Ausente
\.


--
-- Name: conservacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('conservacion_id_seq', 2, true);


--
-- Data for Name: datacion; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY datacion (id, name) FROM stdin;
1	14C
2	AMS
3	No
\.


--
-- Name: datacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('datacion_id_seq', 3, true);


--
-- Data for Name: edad; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY edad (id, name) FROM stdin;
1	Infantil
2	Sub-adulto
3	Adulto joven
4	Adulto medio
5	Adulto mayor
\.


--
-- Name: edad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('edad_id_seq', 5, true);


--
-- Data for Name: ingreso; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY ingreso (id, name) FROM stdin;
1	Donación
2	Excavación
3	Préstamo
4	Rescate
\.


--
-- Name: ingreso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('ingreso_id_seq', 4, true);


--
-- Data for Name: integridad; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY integridad (id, name) FROM stdin;
1	<25%
2	25%-75%
3	>75%
\.


--
-- Name: integridad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('integridad_id_seq', 6, true);


--
-- Data for Name: io; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY io (id, ficharesumen, nroregistro, sitio, acronimo, localidad, provincia, periodo, coordsitio, "precision", dataciones, shueso, materialasoc, arqueologo, fechainicio, fechafin, enterespon, nroregistroarq, sepultura, sexo, edad, "años", integridad, elementoseos, preservacion, conservacion, patalogesquel, patologdientes, elemasoc, otrosasoc, vestimasoc, inventario, fotografias, bibliograf, fechaingreso, caja, sala, estanteria, plano, restoshumanos, otrosrestos, formaingreso, fechasalida, regitroresponsable, conservacrespons, digitalizarespons, bodegaje, observaciones) FROM stdin;
32	QQN0032	0032	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D 14	Esqueleto articulado	M	Sub-adulto	18 - 20	25%-75%	128	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0032#Esquema%20grafico\\QQN0032_CMS_D%2014.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	34	1	3	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
33	QQN0033	0033	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 14 (2)	Esqueleto articulado	F	Sub-adulto	19 - 20	>75%	177	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0033#Esquema%20grafico\\QQN0033_CMS_C14%20(2).JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	35	1	4	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
34	QQN0034	0034	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 11 - 12	Esqueleto articulado	I	Infantil	6 - 9 meses	<25%	20	Regular	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0034#Esquema%20grafico\\QQN0034_CMS_C11_12.jpg#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	36	1	4	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
35	QQN0035	0035	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 11	Esqueleto articulado	I	Infantil	6 meses	<25%	22	Regular	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0035#Esquema%20grafico\\QQN0035_CMS_E11.jpg#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	37	1	4	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
36	QQN0036	0036	Cerro Observación	Cob	Parque Nacional Monte León	Santa Cruz	600 ± 20	50°20' S - 68° 52' W	Aproximada	14C	Si	\N	Ricardo Guichón	Marzo 2010	Marzo 2010	\N	Cerro Observación	Esqueleto articulado	I	Sub-adulto	\N	<25%	\N	Regular	Ausente	\N	\N	Ninguno	\N	\N	QQN0036#Esquema%20grafico\\QQN0036_Cerro%20obserbacion.JPG#	No	\N	2011-05-27 00:00:00	38	1	4	1	Restos humanos	\N	Excavación	2012-11-13 00:00:00	Francesco Lenti	\N	Francesco Lenti	\N	Estos restos fueron devueltos al Reservorio Cogestionado Transitorio Comunidad Mapuche - Tehuelche  Lof Fem-Mapu -  Municipalidad Puerto de Santa Cruz. Ficha Nº PSC0008.-
37	QQN0037	0037	Punta Entrada	PE	Monte Entrance (margen sur del Río Santa Cruz)	Santa Cruz	\N	50°08'09" S – 68°21’54" W	Aproximada	\N	\N	\N	A. Sebastián Muñoz	\N	\N	\N	PE5	Huesos aislados	\N	\N	\N	\N	\N	Regular	Ausente	\N	\N	Ninguno	\N	\N	QQN0037#Esquema%20grafico\\QQN0037_PE5.png#	No	\N	2011-05-27 00:00:00	45	1	2	4	Restos humanos	\N	Rescate	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
38	QQN0038	0038	San Julian	\N	\N	Santa Cruz	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Adulto	\N	\N	\N	Bueno	Ausente	\N	\N	Ninguno	\N	\N	QQN0038#Esquema%20grafico\\QQN0038_San%20Julian.JPG#	No	\N	2011-05-27 00:00:00	47	1	1	5	Restos humanos	\N	Donación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
1	QQN0001	0001	Palermo Aike	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Decada '90	Decada '90	\N	Frailes 1	\N	M	Adulto medio	35-50	25%-75%	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2011-05-27 00:00:00	1	1	1	1	restos humanos	\N	Donación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
2	QQN0002	0002	Las mandibulas 1	LM	Norte Bahía de San Sebastián	Tierra del Fuego Antártida	1770 - 1950 (moderno)	53°3’28” S – 68°30’35” W	Aproximada	14C	Si	\N	A. Sebastián Muñoz	08/01/1994	08/01/1994	CONICET y UBA	Huesos aislados	Huesos aislados	\N	\N	\N	\N	8	Regular	Ausente	No	No	Ninguno	\N	\N	QQN0002#Esquema%20grafico\\QQN0002_Las%20Mandibulas%20huesos%20aislados.png#	Si	Guichón RA, AS Muñoz, Borrero LA.2000.  Datos para una tafonomía de restos óseos humanos en Bahía San Sebastián, Tierra del Fuego. Relaciones de la Sociedad Argentina de Antropologia XXV. PP: 297-311#Pdf%20pubblicazioni\\Las%20mandibulas.pdf#	2012-05-27 00:00:00	2	1	1	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
3	QQN0003	0003	Las mandibulas 1	LM	Norte Bahía de San Sebastián	Tierra del Fuego Antártida	1770 - 1950 (moderno)	53°3’28” S – 68°30’35” W	Exacta	AMS	\N	\N	A. Sebastián Muñoz	19/01/1995	19/01/1995	CONICET y UBA	(LM)19-1-95	Esqueleto articulado	M	Adulto joven	circa 34	>75%	116	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0003#Esquema%20grafico\\QQN0003_Las%20mandibulas%20LM%2019-1-95.jpg#	Si	Guichón RA, AS Muñoz, Borrero LA.2000.  Datos para una tafonomía de restos óseos humanos en Bahía San Sebastián, Tierra del Fuego. Relaciones de la Sociedad Argentina de Antropologia XXV. PP: 297-311#Pdf%20pubblicazioni\\Las%20mandibulas.pdf#	2011-05-27 00:00:00	3	1	1	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
4	QQN0004	0004	San Genaro	SnG	Los Chorillos	Tierra del Fuego Antártida	Moderno	53°19’21” S – 68°17’05” W	Exacta	14C	Si	\N	Luis Alberto Borrero	12/02/2006	12/02/2006	CONICET y UBA	San Genaro II	Huesos aislados	\N	\N	\N	\N	\N	\N	Ausente	No	No	Ninguno	\N	\N	\N	Si	1.\tMartin FM, Barberena R, Guichón RA. 2004. Erosiòn y huesos humanos. El caso de la localidad Chorrillos, Tierra del Fuego.Magallania, (Chile). Vol.32:125-142\r\n2.\tGuichón RA, AS Muñoz, Borrero LA.2000.  Datos para una tafonomía de restos óseos humanos en Bahía San Sebastián, Tierra del Fuego. Relaciones de la Sociedad Argentina de Antropologia XXV. PP: 297-311	2011-05-27 00:00:00	4	1	1	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
5	QQN0005	0005	Palermo Aike	PaK	\N	Santa Cruz	LP-1083 1040±30 AP/ 934-1140 CAL BP	52°07’ S – 69°40' W	Aproximada	14C	\N	Si	Flavia Carballo	1997	1997	Ricardo Guichón	Palermo Aike	\N	M	Adulto joven	\N	<25%	31	Regular	Ausente	No	No	\N	\N	\N	QQN0005#Esquema%20grafico\\QQN0005_Palermo%20Aike%201997.JPG#	No	\N	2011-05-27 00:00:00	5	1	1	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
51	QQN0050	0051	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	E 11 (2)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	59	1	5	\N	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
6	QQN0006	0006	Las Horquetas	LHs	Río Coyle	Santa Cruz	Moderno	51°25' S – 70°16’ W	Aproximada	14C	Si	\N	Luis Alberto Borrero	18/02/1998	18/02/1998	UBACyT F133: “Circulación humana en el extremo sur de Patagonia”	Las Horquetas	Esqueleto articulado	F	Adulto medio	35-50	<25%	50	Regular	Ausente	Si	Si	Ninguno	\N	\N	QQN0006#Esquema%20grafico\\QQN0006_Las%20horquetas.JPG#	No	Borrero LA, Franco NV, Martin FM, Barberena R, Favier Dubois C, Guichon R, Balardi JB. 2006. Las cabeceras del  Coyle: informacion arqueologica y circulacion de poblaciones humanas. La cuenca del rio Coyle. Estado actual de la investigaciones. 1: 75-95#http://Borrero LA, Franco NV, Martin FM, Barberena R, Favier Dubois C, Guichon R, Balardi JB. 2006. Las cabeceras del  Coyle: informacion arqueologica y circulacion de poblaciones humanas. La cuenca del rio Coyle. Estado actual de la investigaciones. 1: 75-95#	2011-05-27 00:00:00	6	1	1	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
7	QQN0007	0007	Cabo Vírgenes	CVs	Santa Cruz	Santa Cruz	Holoceno medio	52°19'97" S – 68°21’31" W	Exacta	No	\N	\N	Luis Alberto Borrero y Ricardo Guichón	Febrero 2000	Febrero 2003	“Distribuciones arqueológicas en escala suprarregional” (Agencia Nacional para la Promoción Científica y Técnica; PICT 97 Nº 04-00000-00807), “Magallania II” (PIP-CONICET) y “Ecología Evolutiva Humana en Patagonia”(SECyT-UNMDP, Nº 04-09929).	C.V.17.1	Esqueleto articulado	M	Adulto joven	\N	25%-75%	128	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0007#Esquema%20grafico\\QQN0007_CV.17.1.jpg#	No	\N	2011-05-27 00:00:00	7-8	1	1	4	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	L’Heureux G, Guichón R,Barberena R, Borrero LA.2003. Durmiendo bajo el faro.Estudio de un entierro humano en Cabo Vírgenes (C.V.17), provincia de Santa Cruz, República Argentina.Intersecion en Antropologia 4: 87-97
8	QQN0008	0008	La Pingüinera	LPü	Puerto Santa Cruz	Santa Cruz	\N	50°08'09" S – 68°21’54" W	Aproximada	\N	\N	\N	Isabel Cruz y Sebastían Muñoz	2003	2003	Isabel Cruz y Sebastían Muñoz	La Pingüinera	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2011-05-27 00:00:00	9	1	1	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	Costillas de nino, restos de muestra para 14C
9	QQN0009	0009	La Veradera Argentina	LVA	Sur Lago Argentino	Santa Cruz	\N	50°53'03" S - 72°14'32" W	Aproximada	\N	\N	\N	Luis Alberto Borrero	31/01/2001	31/01/2001	Luis Alberto Borrero	La Veradera Argentina	Esqueleto articulado	I	Infantil	8 ± 24 meses	<25%	4	Regular	Ausente	No	No	Ninguno	\N	\N	QQN0009#Esquema%20grafico\\QQN0009_La%20veradera%20argentina.JPG#	No	\N	2011-05-27 00:00:00	10	1	1	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
10	QQN0010	0010	Estancia Santa Costancia	ESC	Norte Lago Buenos Aires	Santa Cruz	\N	46°18'27" S - 71°24'33" W	Aproximada	\N	\N	\N	\N	21/10/2003	21/10/2003	Rescatté	Estancia Santa Costancia	\N	I	Infantil	6 - 9 meses	<25%	\N	Regular	\N	\N	\N	\N	\N	\N	QQN0010#Esquema%20grafico\\QQN0010_Estancia%20Santa%20Costancia.JPG#	\N	\N	2011-05-27 00:00:00	11	1	1	5	Restos humanos	\N	Rescatté	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
11	QQN0011	0011	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	14C	Si	\N	M. Ximena Senatore	Primavera 2003	Primavera 2003	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NdJ1	Esqueleto articulado	I	Infantil	10 - 12	>75%	\N	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0011#Esquema%20grafico\\QQN0011_Nombre%20de%20Jesus%20NdJ1.JPG#	Si	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	12	1	2	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
12	QQN0012	0012	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	31/01/2005	31/01/2005	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NJ prox NdJ1	Huesos aislados	\N	\N	\N	\N	\N	Regular	Ausente	\N	\N	Ninguno	\N	\N	QQN0012#Esquema%20grafico\\QQN0012_REGISTRO%20NJ%20prox%20NdJ1.pdf#	\N	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	13	1	2	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
13	QQN0013	0013	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	2005	2005	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NdJ2	Esqueleto articulado	M	Adulto joven	18 - 22	>75%	\N	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0013#Esquema%20grafico\\QQN0013_Nombre%20de%20Jesus%20NdJ2.JPG#	Si	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	14	1	2	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
14	QQN0014	0014	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	2005	2005	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NdJ3	Esqueleto articulado	F	Adulto joven	18 - 23	>75%	\N	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0014#Esquema%20grafico\\QQN0014_Nombre%20de%20Jesus%20NdJ3.JPG#	Si	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	15	1	2	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
15	QQN0015	0015	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	2005	2005	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NdJ4	Esqueleto articulado	M	Adulto joven	20 - 24	>75%	\N	Bueno	Ausente	Si	Si	Otros restos	\N	\N	QQN0015#Esquema%20grafico\\QQN0015_Nombre%20de%20Jesus%20NdJ4.JPG#	Si	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	16	1	2	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
52	QQN0051	0052	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	D 10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	60	1	5	3	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
16	QQN0016	0016	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	2006	2006	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NdJ5	Esqueleto articulado	M	Adulto joven	22 - 26	>75%	\N	Bueno	Ausente	Si	Si	Ninguno	\N	\N	QQN0016#Esquema%20grafico\\QQN0016_Nombre%20de%20Jesus%20NdJ5.JPG#	Si	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	17	1	2	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
17	QQN0017	0017	Nombre de Jesús	NdJ	Cabo Vírgenes	Santa Cruz	1584	52°19’49”S – 68°23’29” W	Exacta	No	\N	\N	M. Ximena Senatore	27/02/2006	27/02/2006	Proyecto ubaCyt F-076 (2004-2007) “sociedad  moderna y Cultura  material” y Fundación  antorchas  subsidio  inicio de Carrera “tiempos modernos en Patagonia”(2004-2007).	NJ prox NdJ5	Huesos aislados	\N	\N	\N	\N	\N	Regular	Ausente	\N	\N	\N	\N	\N	QQN0017#Esquema%20grafico\\QQN0017_REGISTRO%20NJ%20prox%20NdJ5.pdf#	No	Suby J.A., Guichón R, Senatore M.X. 2009. Lo restos óseos humanos de Nombre de Jesús. Evidencia de la salud en el primer asentamiento europeo en Patagonia Austral. Magallania, (Chile), Vol. 37(2): 23-40#Pdf%20pubblicazioni\\Nombre%20de%20Jesus.pdf#	2011-05-27 00:00:00	18	1	2	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
18	QQN0018	0018	Rincón del Buque	RdB	Margen sur del Río Santa Cruz	Santa Cruz	830 ± 42 años AP	53°3’28” S –  68°30’35” W	Exacta	14C	Si	\N	A. Sebastián Muñoz	Marzo 2006	Marzo 2006	\N	Rincón del Buque	Esqueleto articulado	M	Adulto medio	35 - 40	25%-75%	\N	Regular	Ausente	Si	Si	Ninguno	\N	\N	QQN0018#Esquema%20grafico\\QQN0018_Rincon%20del%20buque.JPG#	No	Suby JA, Guichón RA, Zangrando AF.2009. El registro biologico humano de la costa meridional de Santa Cruz. Revista argentina de antropologia biologica 11(1):109-124#Pdf%20pubblicazioni\\Monte%20entrance%20-%20Rincon%20del%20buque%20-%20punta%20entrada.pdf#	2011-05-27 00:00:00	19/20	1	2	5	Restos humanos	\N	Excavación	2012-11-13 00:00:00	Francesco Lenti	\N	Francesco Lenti	\N	Estos restos fueron devueltos al Reservorio Cogestionado Transitorio Comunidad Mapuche - Tehuelche  Lof Fem-Mapu -  Municipalidad Puerto de Santa Cruz. Ficha Nº PSC0009.-
40	QQN0039	0040	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D - 16 (Bis)	Esqueleto articulado	F	Adulto joven	19-29	25%-75%	\N	Bueno	\N	\N	\N	\N	\N	\N	QQN0039#Esquema%20grafico\\QQN0039_CMS_D16Bis.jpg#	\N	\N	2013-03-11 00:00:00	48	1	4	4	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
41	QQN0040	0041	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	\N	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D-16	Esqueleto articulado	\N	Sub-adulto	\N	<25%	14	\N	\N	\N	\N	\N	\N	\N	QQN0040#Esquema%20grafico\\QQN0040_CMS_D16.jpg#	\N	\N	2013-03-11 00:00:00	49	1	4	5	Restor Humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
42	QQN0041	0042	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	\N	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D-E 14	Esqueleto articulado	\N	Sub-adulto	\N	25%-75%	\N	\N	\N	\N	\N	\N	\N	\N	QQN0041#Esquema%20grafico\\QQN0041_CMS_D_E14.jpg#	\N	\N	2013-03-11 00:00:00	50	1	4	5	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
43	QQN0042	0043	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 14-15 (1)	Esqueleto articulado	\N	Sub-adulto	\N	25%-75%	\N	\N	\N	\N	\N	\N	\N	\N	QQN0042#Esquema%20grafico\\QQN0042_CMS_E_14_15_1.jpg#	\N	\N	2013-03-11 00:00:00	51	1	4	4	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
44	QQN0043	0044	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 14-15 (2)	Esqueleto articulado	I	Infantil	5-7	25%-75%	\N	\N	Ausente	\N	\N	\N	\N	\N	QQN0043#Esquema%20grafico\\QQN0043_CMS_E_14_15_2.jpg#	\N	\N	2013-03-15 00:00:00	52	1	4	4	Restos Humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
45	QQN0044	0045	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 15-16 (1)	Esqueleto articulado	I	Infantil	4-10	25%-75%	\N	\N	Ausente	No	\N	\N	\N	\N	QQN0044#Esquema%20grafico\\QQN0044_CMS_E15_16_1.jpg#	\N	\N	2013-03-15 00:00:00	53	1	4	5	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
46	QQN0045	0046	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 15-16 (2Bis)	Esqueleto articulado	F	Adulto medio	30-40	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0045#Esquema%20grafico\\QQN0045_CMS_E15_16_2Bis.jpg#	\N	\N	2013-03-15 00:00:00	54	1	4	3	Restos Humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
47	QQN0046	0047	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichon	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 15-16 (2)	Huesos aislados	I	Sub-adulto	6m-3años	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0046#Esquema%20grafico\\QQN0046_CMS_E15_16_2.jpg#	\N	\N	2013-03-15 00:00:00	55	1	4	5	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
48	QQN0047	0048	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichon	2011	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 15-16 (3)	Esqueleto articulado	M	Adulto medio	35-45	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0047#Esquema%20grafico\\QQN0047_CMS_E15_16_3.jpg#	\N	\N	2013-03-15 00:00:00	56	1	4	3	Restos humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
49	QQN0048	0049	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	E-D 10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0048#Esquema%20grafico\\QQN0048_CMS_E_D_10.jpg#	\N	\N	2013-03-19 00:00:00	57	1	5	2	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
50	QQN0049	0050	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	E 10-11 (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0049#Esquema%20grafico\\QQN0049_CMS_E_10_11_1.jpg#	\N	\N	2013-03-19 00:00:00	58	1	5	2	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
19	QQN0019	0019	Monte Entrada	MnE	Margen sur del Río Santa Cruz	Santa Cruz	400 ± 30	50°08'09" S – 68°21’54" W	Aproximada	14C	Si	\N	A. Sebastián Muñoz	2007	2007	\N	PE 4	Esqueleto articulado	I	Infantil	2 - 4	<25%	\N	Regular	Ausente	Si	Si	Ninguno	\N	\N	QQN0019#Esquema%20grafico\\QQN0019_Monte%20Entrance%20PE4.JPG#	No	Suby JA, Guichón RA, Zangrando AF.2009. El registro biologico humano de la costa meridional de Santa Cruz. Revista argentina de antropologia biologica 11(1):109-124#Pdf%20pubblicazioni\\Monte%20entrance%20-%20Rincon%20del%20buque%20-%20punta%20entrada.pdf#	2011-05-27 00:00:00	21	1	2	4	Restos humanos	\N	Rescate	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
20	QQN0020	0020	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2007	2011	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D-E 13	Huesos aislados	I	Sub-adulto	\N	25%-75%	44	\N	Ausente	Si	Si	Ninguno	\N	\N	QQN0020#Esquema%20grafico\\QQN0020_CMS_D_E_13.jpg#	\N	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	22	1	4	5	Restos humanos	2 4	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	Este esqueleto D-E 13, estuvo fichado anteriormente en tres cajas diferentes como: E 13 (3), D 13 (2) y E 13- 1 (Patricia Palacio 2013).\r\nFragmento de madera (nº talon rosa 501) - caracol - II Material de construcción (zaranda nivel 1) - clavos - Fragmentos indet. (zaranda nivel 1). Los numeros de fichas eran QQN0020 , 0021 y 0022.
21	QQN0021	0021	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	QQN0022	0022	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	QQN0023	0023	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2008	2008	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	E 12 - 13	Esqueleto articulado	M	Adulto medio	35 - 45	>75%	147	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0023#Esquema%20grafico\\QQN0023_CMS_E%2012-13.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	25	1	3	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
24	QQN0024	0024	Punta Entrada	PE	Monte Entrance (margen sur del Río Santa Cruz)	Santa Cruz	\N	50°08'09" S – 68°21’54" W	Aproximada	No	\N	\N	A. Sebastián Muñoz	2007	2007	\N	PE 2	Huesos aislados	F	\N	Adulto	<25%	3	Malo	Ausente	\N	\N	Ninguno	\N	\N	QQN0024#Esquema%20grafico\\QQN0024_PE2.JPG#	No	Suby JA, Guichón RA, Zangrando AF.2009. El registro biologico humano de la costa meridional de Santa Cruz. Revista argentina de antropologia biologica 11(1):109-124#Pdf%20pubblicazioni\\Monte%20entrance%20-%20Rincon%20del%20buque%20-%20punta%20entrada.pdf#	2011-05-27 00:00:00	26	1	2	4	Restos humanos	\N	Rescate	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
25	QQN0025	0025	Punta Entrada	PE	Monte Entrance (margen sur del Río Santa Cruz)	Santa Cruz	\N	50°08'09" S – 68°21’54" W	Aproximada	No	\N	\N	A. Sebastián Muñoz	2007	2007	\N	PE 1	Huesos aislados	I	\N	Adulto	<25%	6	Malo	Ausente	\N	\N	Ninguno	\N	\N	QQN0025#Esquema%20grafico\\QQN0025_PE1.JPG#	No	Suby JA, Guichón RA, Zangrando AF.2009. El registro biologico humano de la costa meridional de Santa Cruz. Revista argentina de antropologia biologica 11(1):109-124#Pdf%20pubblicazioni\\Monte%20entrance%20-%20Rincon%20del%20buque%20-%20punta%20entrada.pdf#	2011-05-27 00:00:00	27	1	2	4	Restos humanos	\N	Rescate	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
26	QQN0026	0026	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2007	2007	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 13	Esqueleto articulado	F	Adulto joven	25 - 35	>75%	167	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0026#Esquema%20grafico\\QQN0026_CMS_C%2013.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	28	1	3	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
27	QQN0027	0027	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 7 - 8	Esqueleto articulado	F	Adulto joven	24 - 26	>75%	194	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0027#Esquema%20grafico\\QQN0027_CMS_C%207-8.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	29	1	3	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
28	QQN0028	0028	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 15	Esqueleto articulado	M	Adulto medio	25 - 39	25%-75%	143	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0028#Esquema%20grafico\\QQN0028_CMS_C%2015.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	30	1	3	1	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
29	QQN0029	0029	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 14 (1)	Esqueleto articulado	I	Sub-adulto	14 - 17	25%-75%	93	Regular	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0029#Esquema%20grafico\\QQN0029_CMS_C14_1.jpg#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	31	1	3	2	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
30	QQN0030	0030	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	D 15 - 16	Esqueleto articulado	F	Adulto medio	35 - 49	>75%	160	Regular	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0030#Esquema%20grafico\\QQN0030_CMS_D%2015-16.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	32	1	3	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
31	QQN0031	0031	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2009	2009	Paleoepidemiologia del Contacto Europeo-Aborigen en Patagonia Austral. PICT 1520 (2007-2010)	C 15 - 16	Esqueleto articulado	F	Adulto mayor	45 - 60	25%-75%	147	Bueno	Ausente	Si	Si	Cajón	Vestimenta asociada	\N	QQN0031#Esquema%20grafico\\QQN0031_CMS_C%2015-16.JPG#	No	García Laborde P, Suby JA,. Guichón RA, Casali R. 2010. El antiguo cementerio de la mision de Rio Grande, Tierra del Fuego. Primeros resultados sobre patologias nutricionales-metabolicas e infecciosas. REVISTA ARGENTINA DE ANTROPOLOGIA BIOLOGICA#Pdf%20pubblicazioni\\El%20cementerio%20de%20la%20missin%20salesiana.pdf#	2011-05-27 00:00:00	33	1	3	3	Restos humanos	\N	Excavación	\N	Francesco Lenti	\N	Francesco Lenti	\N	\N
53	QQN0052	0053	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	D 11 (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	61	1	5	\N	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
54	QQN0053	0054	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	D-C 9-10 (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0053#Esquema%20grafico\\QQN0053_CMS_DC%209_10(1).jpg#	\N	\N	2013-03-19 00:00:00	62	1	5	1	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
55	QQN0054	0055	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	C 10 (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	63	1	5	\N	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
56	QQN0055	0056	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	E 10-11 (2)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0055#Esquema%20grafico\\QQN0055_CMS_E%2010_11_2.jpg#	\N	\N	2013-03-19 00:00:00	64	1	5	1	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
57	QQN0056	0057	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	E-D 11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	65	1	5	4	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
58	QQN0057	0058	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	D-C 11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	66	1	5	3	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
59	QQN0058	0059	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	C 11 (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	QQN0058#Esquema%20grafico\\QQN0058_CMS_C_11_1.jpg#	\N	\N	2013-03-19 00:00:00	67	1	5	3	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
60	QQN0059	0060	El cementerio de la Misión Salesiana	CMS	Rio Grande	Tierra del Fuego Antártida	Siglo XIX - XX	53°44' S - 67° 48' W	Aproximada	No	\N	\N	Ricardo Guichón	2013	2013	Escenarios paleopatológicos y epidemiológicos pre y post contacto interétnico en la Patagonia Austral y\r\nTierra del Fuego - PICT 2010-0575	C 10-11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2013-03-19 00:00:00	68	1	5	4	Resto humanos	\N	Excavación	\N	Patricia Palacio	\N	Patricia Palacio	\N	\N
\.


--
-- Name: io_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('io_id_seq', 60, true);


--
-- Data for Name: localidad; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY localidad (id, name) FROM stdin;
1	Necochea
2	Mar del Plata
3	Buenos Aires
4	Bernal
5	Chubut
6	Santa Cruz
7	Rio Grande
8	Norte Bahía de San Sebastián
9	Los Chorillos
10	Río Coyle
11	Puerto Santa Cruz
12	Sur Lago Argentino
13	Norte Lago Buenos Aires
14	Cabo Vírgenes
15	Margen sur del Río Santa Cruz
16	Monte Entrance (margen sur del Río Santa Cruz)
17	Parque Nacional Monte León
\.


--
-- Name: localidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('localidad_id_seq', 17, true);


--
-- Data for Name: otroresto; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY otroresto (id, name) FROM stdin;
1	1
2	2
3	3
4	4
5	1 2
6	1 3
7	1 4
8	2 3
9	2 4
10	3 4
11	1 2 3
12	1 2 4
13	1 3 4
14	2 3 4
15	1 2 3 4
\.


--
-- Name: otroresto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('otroresto_id_seq', 15, true);


--
-- Data for Name: precision; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY "precision" (id, name) FROM stdin;
1	Exacta
2	Aproximada
\.


--
-- Data for Name: preservacion; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY preservacion (id, name) FROM stdin;
1	Bueno
2	Regular
3	Malo
\.


--
-- Name: preservacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('preservacion_id_seq', 3, true);


--
-- Name: presicion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('presicion_id_seq', 2, true);


--
-- Data for Name: provincia; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY provincia (id, name) FROM stdin;
50	Córdoba
51	Corrientes
52	Entre Ríos
53	Formosa
54	Jujuy
55	La Pampa
56	La Rioja
57	Mendoza
58	Misiones
59	Neuquén
60	Río Negro
61	Salta
62	San Juan
63	San Luis
64	Santa Cruz
65	Santa Fe
66	Santiago del Estero
67	Tierra del Fuego Antártida
68	quequen
45	Ciudad de Buenos Aires
46	Buenos Aires
47	Catamarca
48	Chaco
69	mol
49	Chubut
\.


--
-- Name: provincia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('provincia_id_seq', 80, true);


--
-- Data for Name: sepultura; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY sepultura (id, name) FROM stdin;
1	Esqueleto articulado
2	Huesos aislados
3	Osario
4	Sepultura secundaria
5	Cremación
\.


--
-- Name: sepultura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('sepultura_id_seq', 5, true);


--
-- Data for Name: sexo; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY sexo (id, name) FROM stdin;
7	M
8	F
9	I
\.


--
-- Name: sexo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('sexo_id_seq', 9, true);


--
-- Data for Name: sitio; Type: TABLE DATA; Schema: public; Owner: gpidote
--

COPY sitio (id, name) FROM stdin;
7	Cabo Vírgenes
8	Nombre de Jesús
9	Lomas de Zamora
10	El cementerio de la Misión Salesiana
11	Las mandibulas
12	San Genaro 
13	Palermo Aike
14	Las Horquetas
15	La Pingüinera
16	La Veradera Argentina
17	Estancia Santa Costancia
18	Rincón del Buque
19	Monte Entrada
20	Punta Entrada
21	Cerro Observación
22	San Julian
23	FRAILES
\.


--
-- Name: sitio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gpidote
--

SELECT pg_catalog.setval('sitio_id_seq', 23, true);


--
-- Name: acronimo_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY acronimo
    ADD CONSTRAINT acronimo_pkey PRIMARY KEY (id);


--
-- Name: asociado_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY asociado
    ADD CONSTRAINT asociado_pkey PRIMARY KEY (id);


--
-- Name: conservacion_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY conservacion
    ADD CONSTRAINT conservacion_pkey PRIMARY KEY (id);


--
-- Name: datacion_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY datacion
    ADD CONSTRAINT datacion_pkey PRIMARY KEY (id);


--
-- Name: edad_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY edad
    ADD CONSTRAINT edad_pkey PRIMARY KEY (id);


--
-- Name: ingreso_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY ingreso
    ADD CONSTRAINT ingreso_pkey PRIMARY KEY (id);


--
-- Name: integridad_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY integridad
    ADD CONSTRAINT integridad_pkey PRIMARY KEY (id);


--
-- Name: io_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY io
    ADD CONSTRAINT io_pkey PRIMARY KEY (id);


--
-- Name: localidad_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY localidad
    ADD CONSTRAINT localidad_pkey PRIMARY KEY (id);


--
-- Name: otroresto_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY otroresto
    ADD CONSTRAINT otroresto_pkey PRIMARY KEY (id);


--
-- Name: preservacion_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY preservacion
    ADD CONSTRAINT preservacion_pkey PRIMARY KEY (id);


--
-- Name: presicion_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY "precision"
    ADD CONSTRAINT presicion_pkey PRIMARY KEY (id);


--
-- Name: provincia_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY provincia
    ADD CONSTRAINT provincia_pkey PRIMARY KEY (id);


--
-- Name: sepultura_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY sepultura
    ADD CONSTRAINT sepultura_pkey PRIMARY KEY (id);


--
-- Name: sexo_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY sexo
    ADD CONSTRAINT sexo_pkey PRIMARY KEY (id);


--
-- Name: sitio_pkey; Type: CONSTRAINT; Schema: public; Owner: gpidote; Tablespace: 
--

ALTER TABLE ONLY sitio
    ADD CONSTRAINT sitio_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

